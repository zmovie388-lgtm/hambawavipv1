# HAMBAWA VIP SPECIAL

A responsive, database-backed VIP membership website with a public homepage, dynamic offers, admin login/dashboard, settings, and Telegram deep links.

## Stack

- Node.js + Express
- SQLite (`better-sqlite3`) for persistent offer/settings storage
- `express-session` with a SQLite session store
- bcrypt password hashing, Helmet security headers, login rate limiting
- HTML, CSS, and vanilla JavaScript

## Requirements

- Node.js 20 or newer
- npm
- No paid service is needed for local testing

## Run locally

1. Extract the ZIP and open a terminal in the project folder.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env`.
4. Generate a unique session secret. For example, on Linux/macOS:

   ```bash
   node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
   ```

   Put that value in `SESSION_SECRET` in `.env`. Keep `.env` private and never upload it to a public repository.
5. Configure the initial admin password in your shell environment, then run the setup command. The initial password supplied for this project is `CHALAH@1229@`; use it only for initial setup and change it after the first login.

   Linux/macOS:
   ```bash
   INITIAL_ADMIN_PASSWORD='CHALAH@1229@' npm run setup-admin
   ```

   Windows PowerShell:
   ```powershell
   $env:INITIAL_ADMIN_PASSWORD='CHALAH@1229@'
   npm run setup-admin
   Remove-Item Env:INITIAL_ADMIN_PASSWORD
   ```

   This stores a bcrypt hash in SQLite, not the plaintext password. Do not put the initial password in `.env`, HTML, JavaScript, or logs. If you prefer, choose a stronger initial password when setting up.
6. Start the server:

   ```bash
   npm start
   ```

7. Open `http://localhost:3000`. Tap the gear icon to sign in to `/admin`.

The database and session store are created automatically under `./data/`. Back up the database while the app is stopped, or use SQLite's online backup mechanism if backing up while it is running.

## Admin features

- Add, edit, preview, activate/deactivate, and delete offers
- Automatically calculate discount percentage
- Public homepage shows only active, non-expired offers
- Configure title, group/admin Telegram URLs, membership price, announcement, offer visibility, and contact label
- Change password (minimum 12 characters); the current session is invalidated after a password change
- Session-protected admin APIs, CSRF token checks for state-changing requests, login rate limiting, HttpOnly cookies

## Telegram behavior

- Membership and offer buttons open Telegram with a URL-encoded prefilled message.
- The visitor must press **Send** in Telegram. The site does not send messages automatically.
- This is not a payment processor. The site does not verify payments or grant membership automatically.

## Production deployment

Use a host that supports a persistent Node.js process and persistent disk/volume for SQLite, such as a VPS or a Node-capable application host. Do **not** use static-only hosting (for example, a static site bucket) for this Express backend. SQLite needs persistent disk storage; ephemeral filesystems may erase the database on restart or redeploy. For horizontally scaled deployments or platforms without persistent disk, migrate to PostgreSQL and use a compatible session store.

1. Set `NODE_ENV=production`.
2. Set `SESSION_SECRET` to a long, unique random value (at least 32 characters).
3. Set `DATABASE_PATH` to a path on persistent storage.
4. Configure the initial admin password securely and run `npm run setup-admin` as a one-off setup task. Remove the temporary `INITIAL_ADMIN_PASSWORD` environment variable after setup.
5. Serve the app behind HTTPS. Secure cookies are enabled in production. If the app is behind a trusted reverse proxy, set `TRUST_PROXY=true` only when that proxy correctly terminates HTTPS and sets forwarded headers.
6. Keep `.env`, database files, session files, logs, and backups private. Do not commit secrets or database files.
7. Test login, offer CRUD, settings persistence, session expiration, and backups before opening the site publicly.

### Free hosting notes

Free tiers change frequently. A free Node host is suitable only if it supports a continuously running Express service and persistent disk storage. If the host sleeps or its filesystem is ephemeral, the website may sleep or lose SQLite data. For a stable deployment, use a VPS or a Node host with persistent storage; PostgreSQL is recommended for platforms that do not offer persistent disk. InfinityFree-style static/PHP hosting cannot run this Node/Express backend directly.

## Backups

Stop the server, then copy `data/hambawa.sqlite` and (optionally) `data/sessions.sqlite` to a private backup location. The session database can be omitted; active users will need to sign in again. Never publish the backup file.

## API outline

Public:
- `GET /api/public`
- `GET /api/csrf`

Admin:
- `GET /api/admin/session`
- `POST /api/admin/login`
- `POST /api/admin/logout`
- `GET /api/admin/dashboard`
- `POST /api/admin/offers`
- `PUT /api/admin/offers/:id`
- `DELETE /api/admin/offers/:id`
- `PATCH /api/admin/offers/:id/status`
- `PUT /api/admin/settings`
- `POST /api/admin/password`

## Security notes

- Admin password hashes use bcrypt.
- Never use the same password for unrelated accounts.
- Change the initial password immediately.
- HTTPS is required for production.
- This project is a functional baseline, but before handling high traffic or sensitive business operations, review dependency updates, server logs, host-level access, backups, and deployment configuration.
